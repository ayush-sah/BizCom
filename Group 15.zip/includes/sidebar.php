<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu Open -->
    <div class="panel-heading"><!-- panel-heading Open -->
        <h3 class="panel-title">Products Categories</h3>
    </div><!-- panel-heading Close -->
    <div class="panel-body"><!-- panel-body Open -->
        <ul class="nav nav-pills nav-stacked category-menu"><!-- nav nav-pills nav-stacked categories-menu Open -->
            <?php getPCats(); ?>
        </ul><!-- nav nav-pills nav-stacked categories-menu Close -->
    </div><!-- panel-body Close -->
</div><!-- panel panel-default sidebar-menu Close -->


<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu Open -->
    <div class="panel-heading"><!-- panel-heading Open -->
        <h3 class="panel-title">Categories</h3>
    </div><!-- panel-heading Close -->
    <div class="panel-body"><!-- panel-body Open -->
        <ul class="nav nav-pills nav-stacked category-menu"><!-- nav nav-pills nav-stacked categories-menu Open -->
            <?php getCats(); ?>
        </ul><!-- nav nav-pills nav-stacked categories-menu Close -->
    </div><!-- panel-body Close -->
</div><!-- panel panel-default sidebar-menu Close -->
