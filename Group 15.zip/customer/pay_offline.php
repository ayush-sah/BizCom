<center><!-- center Open -->
   <h1> Pay Offline Using Methods </h1>
    <p class="text-muted">
        If you have any queries, feel free to <a href="../contact.php">contact us</a>. We work <strong>24*7</strong> for our Customers.
    </p>
</center><!-- center Close -->
<div class="table-responsive"><!-- table-responsive Open -->
    <table class="table table-bordered table-hover table-striped"><!-- table table-bordered table-hover Open -->
        <thead><!-- thead Open -->
            <tr><!-- tr Open -->
                <th> Bank Account Details: </th>
                <th> Google Pay: </th>
                <th> Paytm: </th>
            </tr><!-- tr Close -->
        </thead><!-- thead Close -->
        <tbody><!-- tbody Open -->
            <td> Bank Name: SBI | Account No: 1854625102 | Branch Name: Mumbai | IFSC Code: SBIN0000185 </td>
            <td> spit@okGoogle | Mobile no: 902 998 55 33 | Name: SPIT </td>
            <td> Paytm No: 902 998 55 33 </td>
        </tbody><!-- tbody Close -->
    </table><!-- table table-bordered table-hover Close -->
</div><!-- table-responsive Close -->